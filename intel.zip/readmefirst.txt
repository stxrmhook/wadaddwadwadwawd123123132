Important Note
**************

Installing this utility will overwrite some files that are required
for Intel(R) PROSet for Windows Device Manager. This may result in
system bug checks or loss of functionality when using Intel(R) PROSet
or other tools that use the same driver.

Please uninstall Intel PROSet before installing this utility.

**Re-installing Intel PROSet later on could render this tool
useless.**
